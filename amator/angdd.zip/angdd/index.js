'use strict';

var express = require('express');
var blog = require('../models/blog');
var entries = require('../../data/entries.json');

var router = express.Router();

router.get('/posts'), function(req, res) {
  blog.find({}, function(err, entries) {
    if(err) {
      // do something
      return res.status(500).json({message: err.message});
    }
    res.json({entries: entries});
  });
});

module.exports = router;
